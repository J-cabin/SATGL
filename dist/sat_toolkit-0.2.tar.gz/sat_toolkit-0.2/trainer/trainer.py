import torch
from tqdm import tqdm
from sat_toolkit.logger.logger import Logger
from sat_toolkit.model.loss import get_loss
from sat_toolkit.trainer.optimizer import get_optimizer
from sat_toolkit.metric.metric import (
    eval_reduce,
    eval_all_metric,
    eval_compare
)
from torch.utils.tensorboard import SummaryWriter   
from copy import deepcopy

class AbstractTrainer(object):
    def __init__(self, config, model):
        self.config = config
        self.device = config.device
        self.model = model.to(config.device)
        self.logger = Logger(config, name='trainer')
        self.loss = get_loss(config=config)
        self.tensorboard_writer = SummaryWriter(config["tensorboard_dir"])
        self._set_optimizer()
    
    def pred_fn(self, batched_data):
        raise NotImplementedError

    def label_fn(self, batched_data):
        raise NotImplementedError


    @torch.no_grad()
    def evaluate(self, 
                 eval_loader, 
                 **kwargs):
        """
            evaluate model on eval_loader
            Args:
                eval_loader: dataloader for evaluation
                kwargs:
                    pred_fn: function to get prediction from batched_data
                    label_fn: function to get label from batched_data
                    eval_fn: function to evaluate prediction and label
        """
        self.model.eval()
        result_dict = None
        iter_data = (
            tqdm(
                eval_loader,
                total=len(eval_loader),
                ncols=100,
                desc=f"eval "
            )
        )
        if "loss_fn" in kwargs:
            loss_fn = kwargs["loss_fn"]
        else:
            loss_fn = get_loss(config=self.config)
        if "pred_fn" in kwargs:
            pred_fn = kwargs["pred_fn"]
        else:
            pred_fn = self.pred_fn
        if "label_fn" in kwargs:
            label_fn = kwargs["label_fn"]
        else:
            label_fn = self.label_fn
        
        for batch_idx, batched_data in enumerate(iter_data):
            batched_pred = pred_fn(batched_data)
            batched_label = label_fn(batched_data)

            if "eval_fn" in kwargs:
                cur_result_dict = kwargs["eval_fn"](pred=batched_pred, label=batched_label)
            else:
                cur_result_dict = eval_all_metric(config=self.config, pred=batched_pred, label=batched_label)

            result_dict = eval_reduce([result_dict, cur_result_dict])

        
        return result_dict

    def train(self, 
              train_loader, 
              valid_loader=None,
              test_loader=None,
              load_best_model=True,
              **kwargs):
        """
            train model on train_loader
            Args:
                train_loader: dataloader for training
                valid_loader: dataloader for validation
                test_loader: dataloader for testing
                kwargs:
                    loss_fn: function to calculate loss
                    pred_fn: function to get prediction from batched_data
                    label_fn: function to get label from batched_data
                    eval_fn: function to evaluate prediction and label
                    load_best_model: whether to load best model
                    
        """
        valid_metric = self.config["valid_metric"]
        best_result = None
        best_epoch = 0
        best_state_dict = None
        early_stop = self.config["early_stop"]

        for epoch_idx in range(self.config.epochs):
            sum_loss, train_result = self._train_epoch(train_loader=train_loader, **kwargs)

            valid_result = None
            # evaluate model every eval_step epochs
            if (epoch_idx + 1) % self.config.eval_step == 0 and valid_loader is not None:
                valid_result = self.evaluate(valid_loader, **kwargs)
                
            # tensorboard log
            self.tensorboard_writer.add_scalar("train/loss", sum_loss, epoch_idx)
            if valid_metric != "loss":
                self.tensorboard_writer.add_scalar(f"train/{valid_metric}", train_result[valid_metric], epoch_idx)
            
            # output result
            self.logger.info(f"epoch [{epoch_idx}/{self.config.epochs - 1}] loss : {sum_loss}")
            self.logger.info(f"train_result : {train_result}")
            if valid_result is not None:
                self.logger.info(f"valid_result : {valid_result}")
                if valid_metric != "loss":
                    self.tensorboard_writer.add_scalar(f"eval/{valid_metric}", valid_result[valid_metric], epoch_idx)
                
            
            if load_best_model == True:
                if valid_metric == "loss":
                    current_valid_result = sum_loss
                else:
                    current_valid_result = valid_result[valid_metric]
                
                if eval_compare(valid_metric, current_valid_result, best_result):
                    best_result = current_valid_result
                    best_epoch = epoch_idx
                    best_state_dict = deepcopy(self.model.state_dict())
                elif early_stop is not False and epoch_idx - best_epoch >= early_stop:
                    self.logger.info(f"early stop at epoch {epoch_idx}")
                    break
        
        if load_best_model == True:
            self.model.load_state_dict(best_state_dict)
            self.logger.info(f"load best model at epoch {best_epoch}")
        else:
            self.logger.info(f"load last model at epoch {epoch_idx}")

        # eval test 
        if test_loader is not None:
            test_result = self.evaluate(test_loader, **kwargs)
            self.logger.info(f"test_result : {test_result}")
            
        # save model
        if self.config.save_model != False:
            self.logger.info(f"save model at epoch {best_epoch} to {self.config.save_model}")
            torch.save(self.model.state_dict(), self.config.save_model)     
            
        # close writer
        self.tensorboard_writer.close()

    def _train_epoch(self, 
                     train_loader,
                     **kwargs):
        # get loss function
        if "loss_fn" in kwargs:
            loss_fn = kwargs["loss_fn"]
        else:
            loss_fn = get_loss(config=self.config)
        if "pred_fn" in kwargs:
            pred_fn = kwargs["pred_fn"]
        else:
            pred_fn = self.pred_fn
        if "label_fn" in kwargs:
            label_fn = kwargs["label_fn"]
        else:
            label_fn = self.label_fn

        sum_loss = 0
        iter_data = (
            tqdm(
                train_loader,
                total=len(train_loader),
                ncols=100,
                desc = f"train "
            )
        )
        result_dict = None 
        for batch_idx, batched_data in enumerate(iter_data):
            self.model.train()
            self.optimizer.zero_grad()
            if pred_fn is not None: 
                batched_pred = pred_fn(batched_data)
            else:
                batched_pred = self.pred_fn(batched_data)
            if label_fn is not None:
                batched_label = label_fn(batched_data)
            else:
                batched_label = self.label_fn(batched_data)
            loss = loss_fn(batched_pred, batched_label)

            loss.backward()
            self.optimizer.step()
            self.optimizer.zero_grad()
            sum_loss += loss.item()

            self.model.eval()
            if "eval_fn" in kwargs:
                cur_result_dict = kwargs["eval_fn"](pred=batched_pred, label=batched_label)
            else:
                cur_result_dict = eval_all_metric(config=self.config, pred=batched_pred, label=batched_label)

            result_dict = eval_reduce([result_dict, cur_result_dict])

        return sum_loss, result_dict
    
    def _set_optimizer(self):
        self.optimizer = get_optimizer(config=self.config)(
            params=self.model.parameters(),
            lr=float(self.config.lr),
            weight_decay=float(self.config.weight_decay)
        )

class GraphTaskTrainer(AbstractTrainer):
    def __init__(self, config, model):
        super(GraphTaskTrainer, self).__init__(config=config, model=model)

        if config["task_type"] != "graph":
            raise ValueError("task type not match")
    
    def pred_fn(self, batched_data):
        batched_g = batched_data["g"].to(self.device)
        batched_info = batched_data["info"]
        batched_feature = batched_g.ndata["feature"].to(self.device)
        batched_pred = self.model.graph_forward(batched_g, batched_feature, batched_info)
        return batched_pred

    def label_fn(self, batched_data):
        batched_label = batched_data["label"].to(self.device)
        return batched_label

class NodeTaskTrainer(AbstractTrainer):
    def __init__(self, config, model):
        super(NodeTaskTrainer, self).__init__(config=config, model=model)

        if config["task_type"] != "node":
            raise ValueError("task type not match")
    
    def pred_fn(self, batched_data):
        batched_g = batched_data["g"].to(self.device)
        batched_info = batched_data["info"]
        batched_feature = batched_g.ndata["feature"].to(self.device)
        batched_pred = self.model.node_forward(batched_g, batched_feature, batched_info)
        return batched_pred

    def label_fn(self, batched_data):
        batched_label = batched_data["label"].to(self.device).squeeze(0)
        return batched_label

class TaskTrainer(AbstractTrainer):
    def __init__(self, config, model):
        super(TaskTrainer, self).__init__(config=config, model=model)
    
    def pred_fn(self, batched_data):
        batched_g = batched_data["g"].to(self.device)
        batched_info = batched_data["info"]
        batched_feature = batched_g.ndata["feature"].to(self.device)
        batched_pred = self.model.forward(batched_g, batched_feature, batched_info)
        return batched_pred

    def label_fn(self, batched_data):
        batched_label = batched_data["label"].to(self.device).squeeze(0)
        return batched_label
