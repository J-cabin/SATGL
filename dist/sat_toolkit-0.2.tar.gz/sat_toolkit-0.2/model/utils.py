import torch

def flip(l_msg, l_pos_index, l_neg_index):
    """
        flip pos and neg literal msg to
            pos1 -> neg1
            pos2 -> neg2
                ...
            neg1 -> pos1
            neg2 -> pos2
    """
    l_flip_msg = torch.zeros_like(l_msg)
    l_flip_msg[l_pos_index] = l_msg[l_neg_index]
    l_flip_msg[l_neg_index] = l_msg[l_pos_index]
    return l_flip_msg