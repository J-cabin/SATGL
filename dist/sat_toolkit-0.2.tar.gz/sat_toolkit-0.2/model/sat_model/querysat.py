import torch
import dgl

from sat_toolkit.model.sat_model.abstract_model import AbstractSATModel

import torch.nn as nn
from torch.nn.functional import softmax

from ..layer.mlp import MLP
from ..layer.querysat_layer import QuerySATLayer
from dgl.nn.pytorch.conv import GraphConv
from dgl import node_subgraph

class QuerySAT(nn.Module):
    """
        QuerySAT
    """
    def __init__(self, config, dataset):
        super(QuerySAT, self).__init__()
        self.config = config

        # check config
        if config["graph_type"] not in ["lcg"]:
            raise ValueError("QuerySAT only support lcg graph.")

        self.device = config.device
        self.input_size = dataset.feature_size
        self.hidden_size = config.model_settings["hidden_size"]
        self.output_size = config.model_settings["output_size"]
        self.query_num_mlp_layer = config.model_settings["query_num_mlp_layer"]
        self.literal_num_mlp_layer = config.model_settings["literal_num_mlp_layer"]
        self.clause_num_mlp_layer = config.model_settings["clause_num_mlp_layer"]
        self.output_num_mlp_layer = config.model_settings["output_num_mlp_layer"]
        self.num_round = config.model_settings["num_round"]
        self.residual_weight = config.model_settings["residual_weight"]
        
        # init
        self.L_init = nn.Linear(self.input_size, self.hidden_size)
        self.C_init = nn.Linear(self.input_size, self.hidden_size)

        # neurosat layer
        self.querysat_layer = QuerySATLayer(
            emb_size=self.hidden_size,
            query_num_mlp_layer=self.query_num_mlp_layer,
            literal_num_mlp_layer=self.literal_num_mlp_layer,
            clause_num_mlp_layer=self.clause_num_mlp_layer,
            residual_weight=self.residual_weight
        )

        # output
        self.o_mlp = MLP(self.hidden_size, self.hidden_size, self.output_size, num_layer=self.output_num_mlp_layer)

        # sigmoid
        self.sigmoid = nn.Sigmoid()

    def graph_forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        v_embedding = self.L_init(embedding[l_pos_index])
        c_embedding = self.C_init(embedding[c_index])

        # node embedding 
        node_embedding = torch.zeros(num_node, self.hidden_size).to(self.device)
        node_embedding[l_index][0::2, :] = v_embedding
        node_embedding[l_index][1::2, :] = v_embedding
        node_embedding[c_index] = c_embedding

        for round_idx in enumerate(range(self.num_round)):
            node_embedding = self.querysat_layer(
                node_embedding = node_embedding,
                graph = graph
            )

        # readout
        v_embedding = node_embedding[l_pos_index]
        v_out = self.sigmoid(self.o_mlp(v_embedding))
        pred = dgl.ops.segment_reduce(num_variable, v_out, "mean").squeeze(-1)
        pred = self.sigmoid(pred)
        
        return pred