import torch
import dgl

from sat_toolkit.model.sat_model.abstract_model import AbstractSATModel

import torch.nn as nn
from torch.nn.functional import softmax

from ..layer.mlp import MLP
from ..layer.neurosat_layer import NeuroSATLayer
from dgl.nn.pytorch.conv import GraphConv
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl import node_subgraph

class GMS(nn.Module):
    """
        GMS from Can Graph Neural Networks Learn to Solve MaxSAT Problem?

    """
    def __init__(self, config, dataset):
        super(GMS, self).__init__()
        self.config = config
        
        # check config
        if config["graph_type"] not in ["lcg"]:
            raise ValueError("NeuroSAT only support lcg graph.")

        self.device = config.device
        self.input_size = dataset.feature_size
        self.hidden_size = config.model_settings["hidden_size"]
        self.output_size = config.model_settings["output_size"]
        self.num_fc = config.model_settings["num_fc"]
        self.num_round = config.model_settings["num_round"]

        # neurosat layer
        self.neurosat_layer = NeuroSATLayer(emb_size=self.hidden_size,num_fc=self.num_fc,)
        
        # init
        self.L_init = nn.Linear(self.input_size, self.hidden_size)
        self.C_init = nn.Linear(self.input_size, self.hidden_size)

        # output
        self.L_out = MLP(self.hidden_size, self.hidden_size, self.output_size, num_layer=self.num_fc)

        # conv
        self.graph_conv = GraphConv(self.hidden_size, self.hidden_size, 
                                    allow_zero_in_degree=True, bias=False, 
                                    norm="none", weight=False)
        # vote layer
        self.var_vote = nn.Linear(self.hidden_size * 2, 1)

        # sigmoid
        self.sigmoid = nn.Sigmoid()

    def node_forward(self, graph, embedding, info=None):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        l_embedding = self.L_init(embedding[l_index])
        c_embedding = self.C_init(embedding[c_index])

        # init state 
        l_state = (l_embedding.unsqueeze(0), torch.zeros(1, l_embedding.shape[0], self.hidden_size).to(self.device))
        c_state = (c_embedding.unsqueeze(0), torch.zeros(1, c_embedding.shape[0], self.hidden_size).to(self.device))

        # update embedding using nerucore layer
        for round_idx in range(self.num_round):
            l_state, c_state = self.neurosat_layer(
                l_state = l_state,
                c_state = c_state,
                graph = graph
            )

        # pooling 
        # join literal embedding and clause embedding 
        l_embedding = l_state[0].squeeze(0)
        c_embedding = c_state[0].squeeze(0)
        all_embedding = torch.zeros(num_node, self.hidden_size).to(self.device)
        all_embedding[l_index] = l_embedding
        all_embedding[c_index] = c_embedding
        v_embedding = torch.cat([
            torch.index_select(all_embedding, dim=0, index=l_pos_index),
            torch.index_select(all_embedding, dim=0, index=l_neg_index)
        ], dim=1)
        v_vote = self.var_vote(v_embedding)
        pred = self.sigmoid(v_vote).squeeze(-1)
        return pred

