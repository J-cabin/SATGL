import torch
import dgl

from sat_toolkit.model.sat_model.abstract_model import AbstractSATModel

import torch.nn as nn
from torch.nn.functional import softmax

from ..utils import flip
from ..layer.mlp import MLP
from ..layer.neurocore_layer import NeuroCoreLayer
from dgl.nn.pytorch.conv import GraphConv
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl import node_subgraph

class NeuroCore(nn.Module):
    """
        Recurrent Graph Neural Networks of NeuroSAT.
    """
    def __init__(self, config, dataset):
        super(NeuroCore, self).__init__()
        self.config = config

        # check config
        if config["graph_type"] not in ["lcg"]:
            raise ValueError("NeuroCore only support lcg graph.")

        self.device = config.device
        self.input_size = dataset.feature_size
        self.hidden_size = config.model_settings["hidden_size"]
        self.output_size = config.model_settings["output_size"]
        self.num_fc = config.model_settings["num_fc"]
        self.num_round = config.model_settings["num_round"]
        
        # init
        self.L_init = nn.Linear(self.input_size, self.hidden_size)
        self.C_init = nn.Linear(self.input_size, self.hidden_size)

        # neurocore layer
        self.neurocore_layer = NeuroCoreLayer(emb_size=self.hidden_size,num_fc=self.num_fc,)

        # output    
        self.v_out = MLP(self.hidden_size * 2, self.hidden_size, self.output_size, num_layer=self.num_fc)
        self.l_out = MLP(self.hidden_size, self.hidden_size, self.output_size, num_layer=self.num_fc)
        self.sigmoid = nn.Sigmoid()
        
    def node_forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        l_embedding = self.L_init(embedding[l_index])
        c_embedding = self.C_init(embedding[c_index])
        node_embedding = torch.empty(num_node, self.hidden_size).to(self.device)
        node_embedding[l_index] = l_embedding
        node_embedding[c_index] = c_embedding


        for round_idx in enumerate(range(self.num_round)):
            node_embedding = self.neurocore_layer(
                node_embedding = node_embedding,
                graph = graph
            )

        # pooling
        l_embedding = node_embedding[l_index]
        flip_embedding = flip(l_embedding)
        join_embedding = torch.cat([l_embedding, flip_embedding], dim=-1)
        v_embedding = self.v_out(join_embedding).squeeze(-1)
    
        return v_embedding
    
    def graph_forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        l_all_embedding = self.L_init(embedding)
        c_all_embedding = self.C_init(embedding)
        node_embedding = l_all_embedding * l_mask + c_all_embedding * c_mask
        

        for round_idx in enumerate(range(self.num_round)):
            node_embedding = self.neurocore_layer(
                node_embedding = node_embedding,
                graph = graph
            )

        # pooling
        # pos_embedding = node_embedding[l_pos_index]
        # neg_embedding = node_embedding[l_neg_index]
        # v_join_embedding = torch.cat([pos_embedding, neg_embedding], dim=-1)
        # v_embedding = self.v_out(v_join_embedding)
        # graph_embedding = dgl.ops.segment_reduce(num_variable, v_embedding, reducer="mean")
        # pred = self.sigmoid(graph_embedding).squeeze(-1)
        l_embedding = node_embedding[l_index]
        l_vote = self.l_out(l_embedding)
        graph_embedding = dgl.ops.segment_reduce(num_variable * 2, l_vote, reducer="mean")
        pred = self.sigmoid(graph_embedding).squeeze(-1)
        return pred