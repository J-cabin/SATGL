import torch
import dgl

from sat_toolkit.model.sat_model.abstract_model import AbstractSATModel

import torch.nn as nn
from torch.nn.functional import softmax

from ..layer.mlp import MLP
from ..layer.deepsat_conv import DeepSATConv
from ..layer.readout_layer import ReadoutLayer
from torch.nn import GRU
from dgl.nn.pytorch.conv import GraphConv
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl import node_subgraph
from dgl import edge_subgraph

class DeepSAT(nn.Module):
    """
        DeepSAT: An EDA-Driven Learning Framework for SAT.
    """
    def __init__(self, config, dataset):
        super(DeepSAT, self).__init__()
        self.config = config

        # check config
        if config["graph_type"] not in ["aig"]:
            raise ValueError("DeepSAT only support aig graph.")

        self.device = config.device
        self.input_size = dataset.feature_size
        self.hidden_size = config.model_settings["hidden_size"]
        self.output_size = config.model_settings["output_size"]
        self.num_fc = config.model_settings["num_fc"]
        self.num_round = config.model_settings["num_round"]
        self.mask = config.model_settings["mask"]
        self.reverse = config.model_settings["reverse"]
        
        # init
        self.h_init = nn.Linear(self.input_size, self.hidden_size)

        # conv
        self.deepsat_conv = DeepSATConv(emb_size=self.hidden_size)

        # update
        self.forward_update = GRU(self.hidden_size + self.input_size, self.hidden_size)
        if self.reverse:
            self.backward_update = GRU(self.hidden_size + self.input_size, self.hidden_size)
        
        # out
        self.out = nn.Linear(self.hidden_size, self.output_size)
        
        # sigmoid
        self.sigmoid = nn.Sigmoid()
        
        # readout
        self.readout_layer = ReadoutLayer(
            input_size=self.hidden_size,
            output_size=self.output_size,
            pooling=config["model_settings"]["pooling"],
            num_fc=self.num_fc,
            embedding_type="node",
            sigmoid=config["model_settings"]["sigmoid"],
            task_type=config["task_type"]
        )

    def dag_forward(self, graph, embedding, node_type_embedding, info):
        # edge index
        forward_edge = torch.stack([graph.edges()[0], graph.edges()[1]], dim=0).to(self.device)
        backward_edge = torch.stack([graph.edges()[1], graph.edges()[0]], dim=0).to(self.device)

        # depth
        forward_depth = int(info["forward_level"].max().item())
        backward_depth = int(info["backward_level"].max().item())
        
        # level
        forward_level = info["forward_level"].to(self.device)
        backward_level = info["backward_level"].to(self.device)

        # forward process
        new_embedding = embedding.clone()
        tmp_msg = torch.zeros_like(embedding)
        for forward_idx in range(1, forward_depth):
            # get the edge index and node index of the current layer
            layer_mask = (forward_level[forward_edge[1]] == forward_idx).to(self.device)
            sub_graph_edge_idx = torch.arange(0, forward_edge.shape[1]).to(self.device)[layer_mask]
            layer_node_idx = torch.unique(forward_edge[1][layer_mask])

            # extract the subgraph
            sub_graph = edge_subgraph(graph, sub_graph_edge_idx, relabel_nodes=True)
            sub_embedding = new_embedding[sub_graph.ndata[dgl.NID]]

            # deepsat conv
            sub_msg = self.deepsat_conv(sub_graph, sub_embedding)
            tmp_msg[sub_graph.ndata[dgl.NID]] = sub_msg
            layer_msg = tmp_msg[layer_node_idx]
            layer_node_type = node_type_embedding[layer_node_idx]
            layer_embedding = new_embedding[layer_node_idx]

            # update 
            _, layer_embedding = self.forward_update(
                torch.cat([layer_msg, layer_node_type], dim=1).unsqueeze(0),
                layer_embedding.unsqueeze(0)
            )
            new_embedding[layer_node_idx] = layer_embedding.squeeze(0)
        embedding = new_embedding
        
        # backward process
        if self.reverse:
            new_embedding = embedding.clone()
            tmp_msg = torch.zeros_like(embedding)
            for backward_idx in range(1, backward_depth):
                # get the edge index and node index of the current layer
                layer_mask = (backward_level[backward_edge[1]] == backward_idx).to(self.device)
                sub_graph_edge_idx = torch.arange(0, backward_edge.shape[1]).to(self.device)[layer_mask]
                layer_node_idx = torch.unique(backward_edge[1][layer_mask])

                # extract the subgraph
                sub_graph = edge_subgraph(graph, sub_graph_edge_idx, relabel_nodes=True)
                sub_embedding = new_embedding[sub_graph.ndata[dgl.NID]]

                # deepsat conv
                sub_msg = self.deepsat_conv(sub_graph, sub_embedding)
                tmp_msg[sub_graph.ndata[dgl.NID]] = sub_msg
                layer_msg = tmp_msg[layer_node_idx]
                layer_node_type = node_type_embedding[layer_node_idx]
                layer_embedding = new_embedding[layer_node_idx]

                # update 
                _, layer_embedding = self.backward_update(
                    torch.cat([layer_msg, layer_node_type], dim=1).unsqueeze(0),
                    layer_embedding.unsqueeze(0)
                )
                new_embedding[layer_node_idx] = layer_embedding.squeeze(0)
            embedding = new_embedding
        
        return embedding



    def graph_forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()

        # init 
        h_init = self.h_init(embedding)
        node_type_embedding = embedding

        # mask
        if self.mask:
            mask = graph.ndata["mask"]
            h_true = torch.ones_like(h_init)
            h_false = -torch.ones_like(h_init)
            h_true.requires_grad = False
            h_false.requires_grad = False

            h_init = self.apply_mask(h_init, mask, h_true, h_false)

        # dag forward
        for round_idx in range(self.num_round):
            h_init = self.dag_forward(graph, h_init, node_type_embedding, info)

        # readout
        out = self.out(h_init)
        pred = self.sigmoid(out).squeeze(-1)
        return pred

    def apply_mask(self, h, mask, h_true, h_false):
        true_mask = (mask == 1).unsqueeze(-1)
        false_mask = (mask == -1).unsqueeze(-1)
        not_assign_mask = (mask == 0).unsqueeze(-1)
        mask_h = h * not_assign_mask + h_true * true_mask + h_false * false_mask
        return mask_h
    
    def forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()

        # init 
        h_init = self.h_init(embedding)
        node_type_embedding = embedding

        # mask
        if self.mask:
            mask = graph.ndata["mask"]
            h_true = torch.ones_like(h_init)
            h_false = -torch.ones_like(h_init)
            h_true.requires_grad = False
            h_false.requires_grad = False

            h_init = self.apply_mask(h_init, mask, h_true, h_false)

        # dag forward
        for round_idx in range(self.num_round):
            h_init = self.dag_forward(graph, h_init, node_type_embedding, info)

        # readout
        pred = self.readout_layer(graph, h_init, info)
        return pred