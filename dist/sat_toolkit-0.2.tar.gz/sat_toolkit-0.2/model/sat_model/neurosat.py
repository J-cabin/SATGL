import torch
import dgl

from sat_toolkit.model.sat_model.abstract_model import AbstractSATModel

import torch.nn as nn
from torch.nn.functional import softmax

from ..layer.mlp import MLP
from ..layer.neurosat_layer import NeuroSATLayer
from ..layer.readout_layer import ReadoutLayer
from dgl.nn.pytorch.conv import GraphConv
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl import node_subgraph

class NeuroSAT(nn.Module):
    """
        Recurrent Graph Neural Networks of NeuroSAT.
    """
    def __init__(self, config, dataset):
        super(NeuroSAT, self).__init__()
        self.config = config

        # check config
        if config["graph_type"] not in ["lcg"]:
            raise ValueError("NeuroSAT only support lcg graph.")

        self.device = config.device
        self.input_size = dataset.feature_size
        self.hidden_size = config.model_settings["hidden_size"]
        self.output_size = config.model_settings["output_size"]
        self.num_fc = config.model_settings["num_fc"]
        self.num_round = config.model_settings["num_round"]
        
        # init
        self.L_init = nn.Linear(self.input_size, self.hidden_size)
        self.C_init = nn.Linear(self.input_size, self.hidden_size)

        # neurosat layer
        self.neurosat_layer = NeuroSATLayer(emb_size=self.hidden_size,num_fc=self.num_fc)

        # output
        self.L_out = MLP(self.hidden_size, self.hidden_size, self.output_size, num_layer=self.num_fc)

        # sigmoid
        self.sigmoid = nn.Sigmoid()
        
        # readout
        self.readout_layer = ReadoutLayer(
            input_size=self.hidden_size,
            output_size=self.output_size,
            pooling=config["model_settings"]["pooling"],
            num_fc=self.num_fc,
            embedding_type="literal",
            sigmoid=config["model_settings"]["sigmoid"],
            task_type=config["task_type"]
        )

    def graph_forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        l_embedding = self.L_init(embedding[l_index])
        c_embedding = self.C_init(embedding[c_index])

        # init state 
        l_state = (l_embedding.unsqueeze(0), torch.zeros(1, l_embedding.shape[0], self.hidden_size).to(self.device))
        c_state = (c_embedding.unsqueeze(0), torch.zeros(1, c_embedding.shape[0], self.hidden_size).to(self.device))

        for round_idx in enumerate(range(self.num_round)):
            l_state, c_state = self.neurosat_layer(
                l_state = l_state,
                c_state = c_state,
                graph = graph
            )

        # pooling 
        # l_embedding = l_state[0].squeeze(0)
        # l_vote = self.L_out(l_embedding)
        # l_vote_mean = dgl.ops.segment_reduce(num_variable * 2, l_vote, reducer="mean")
        # pred = self.sigmoid(l_vote_mean).squeeze(-1)
        # return pred
        
        # readout
        pred = self.readoutlayer(graph, l_state[0].squeeze(0), info)
        return pred

    def forward(self, graph, embedding, info):
        num_node = graph.number_of_nodes()
        num_variable = info["num_variable"].to(self.device)
        
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(self.device)
        l_neg_mask = (node_type == 1).to(self.device)
        l_mask = l_pos_mask | l_neg_mask
        c_mask = (node_type == 2).to(self.device)
        
        l_pos_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_neg_mask.squeeze(-1)]
        l_index = torch.arange(0, embedding.shape[0]).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, embedding.shape[0]).to(self.device)[c_mask.squeeze(-1)]

        # init embedding
        l_embedding = self.L_init(embedding[l_index])
        c_embedding = self.C_init(embedding[c_index])

        # init state 
        l_state = (l_embedding.unsqueeze(0), torch.zeros(1, l_embedding.shape[0], self.hidden_size).to(self.device))
        c_state = (c_embedding.unsqueeze(0), torch.zeros(1, c_embedding.shape[0], self.hidden_size).to(self.device))

        for round_idx in enumerate(range(self.num_round)):
            l_state, c_state = self.neurosat_layer(
                l_state = l_state,
                c_state = c_state,
                graph = graph
            )

        # pooling 
        # l_embedding = l_state[0].squeeze(0)
        # l_vote = self.L_out(l_embedding)
        # l_vote_mean = dgl.ops.segment_reduce(num_variable * 2, l_vote, reducer="mean")
        # pred = self.sigmoid(l_vote_mean).squeeze(-1)
        # return pred
        
        # readout
        pred = self.readout_layer(graph, l_state[0].squeeze(0), info)
        return pred