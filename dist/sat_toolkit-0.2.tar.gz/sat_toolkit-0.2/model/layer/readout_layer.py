import torch
import dgl

import torch.nn as nn
from torch.nn.functional import softmax

from ..layer.mlp import MLP
from dgl.nn.pytorch.conv import GraphConv
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl import node_subgraph

class ReadoutLayer(nn.Module):
    """
        readout layer for graph and node level
    """
    def __init__(self, 
                 input_size,
                 output_size,
                 pooling="mean",
                 num_fc=3,
                 embedding_type="literal",
                 sigmoid=True,
                 task_type="graph"):
        super(ReadoutLayer, self).__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.pooling = pooling
        self.num_fc = num_fc
        self.embedding_type = embedding_type
        self.task_type = task_type
        
        # build linear layers
        if self.embedding_type == "literal" :
            self.l_out = MLP(self.input_size, self.input_size, self.output_size, num_layer=self.num_fc)
        if self.embedding_type == "varibale":
            self.v_out = MLP(self.input_size, self.input_size, self.output_size, num_layer=self.num_fc)
        if self.embedding_type == "clause":
            self.c_out = MLP(self.input_size, self.input_size, self.output_size, num_layer=self.num_fc)
        if self.embedding_type == "edge":
            self.e_out = MLP(self.input_size, self.input_size, self.output_size, num_layer=self.num_fc)
        if self.embedding_type == "node":
            self.n_out = MLP(self.input_size, self.input_size, self.output_size, num_layer=self.num_fc)
        
        # sigmoid
        if sigmoid:
            self.sigmoid = nn.Sigmoid()
            
    def literal_readout(self, graph, l_embedding, info):
        device = l_embedding.device
        num_variable = info["num_variable"].to(device)
        l_vote = self.l_out(l_embedding)
        
        if self.task_type == "graph":
            l_vote_pooling = dgl.ops.segment_reduce(num_variable * 2, l_vote, reducer=self.pooling)
            pred = l_vote_pooling.squeeze(-1)
        elif self.task_type == "node":
            pred = l_vote.squeeze(-1)
        else:
            raise ValueError("task type error")
        
        if self.sigmoid:
            pred = self.sigmoid(pred)
            
        return pred

    def variable_readout(self, graph, v_embedding, info):
        device = v_embedding.device
        num_variable = info["num_variable"].to(device)
        v_vote = self.v_out(v_embedding)
        
        if self.task_type == "graph":
            v_vote_pooling = dgl.ops.segment_reduce(num_variable, v_vote, reducer=self.pooling)
            pred = v_vote_pooling.squeeze(-1)
        elif self.task_type == "node":
            pred = v_vote.squeeze(-1)
        else:
            raise ValueError("task type error")
        
        if self.sigmoid:
            pred = self.sigmoid(pred)
            
        return pred

    def node_readout(self, graph, n_embedding, info):
        device = n_embedding.device
        num_node = info["num_node"].to(device)
        n_vote = self.n_out(n_embedding)
        
        if self.task_type == "graph":
            n_vote_pooling = dgl.ops.segment_reduce(num_node, n_vote, reducer=self.pooling)
            pred = n_vote_pooling.squeeze(-1)
        elif self.task_type == "node":
            pred = n_vote.squeeze(-1)
        else:
            raise ValueError("task type error")
        
        if self.sigmoid:
            pred = self.sigmoid(pred)
            
        return pred

    def edge_readout(self, graph, e_embedding, info):
        device = e_embedding.device
        num_node = graph.number_of_nodes()
        num_edge = graph.number_of_edges()
        num_variable = info["num_variable"].to(device)
        edge_index = torch.cat([graph.edges()[0].unsqueeze(-1), 
                                graph.edges()[1].unsqueeze(-1)], dim=-1).to(device)
        # get mask & index
        node_type = graph.ndata["node_type"].unsqueeze(-1)
        edge_type = graph.edata["edge_type"].unsqueeze(-1)
        l_pos_mask = (node_type == 0).to(device)
        l_neg_mask = (node_type == 1).to(device)
        real_l2c_mask = (edge_type == 1).to(device)
        virtual_l2c_mask = (edge_type == 0).to(device)
        real_c2l_mask = (edge_type == 2).to(device)
        virtual_c2l_mask = (edge_type == 3).to(device)
        l_mask = (node_type != 2).to(device)
        c_mask = (node_type == 2).to(device)
        
        real_l2c_index = torch.arange(0, num_edge).to(self.device)[real_l2c_mask.squeeze(-1)]
        virtual_l2c_index = torch.arange(0, num_edge).to(self.device)[virtual_l2c_mask.squeeze(-1)]
        real_c2l_index = torch.arange(0, num_edge).to(self.device)[real_c2l_mask.squeeze(-1)]
        virtual_c2l_index = torch.arange(0, num_edge).to(self.device)[virtual_c2l_mask.squeeze(-1)]
        l_index = torch.arange(0, num_node).to(self.device)[l_mask.squeeze(-1)]
        c_index = torch.arange(0, num_node).to(self.device)[c_mask.squeeze(-1)]
        l_pos_index = torch.arange(0, num_node).to(self.device)[l_pos_mask.squeeze(-1)]
        l_neg_index = torch.arange(0, num_node).to(self.device)[l_neg_mask.squeeze(-1)]
        
        # aggr
        aggr_embedding = torch.zeros(num_node, self.input_size).to(device)
        aggr_embedding = dgl.ops.u_add_e_sum(graph, aggr_embedding, e_embedding)
        l_embedding = aggr_embedding[l_index]
        
        if self.task_type == "graph":
            l_vote_mean = dgl.ops.segment_reduce(num_variable * 2, l_embedding, reducer=self.pooling)
            pred = self.sigmoid(self.readout(l_vote_mean).squeeze(-1))
        elif self.task_type == "node":
            pred = l_embedding.squeeze(-1)
        
        if self.sigmoid:
            pred = self.sigmoid(pred)
            
        return pred
    
    def forward(self, graph, embedding, info):
        forward_func = getattr(self, self.embedding_type + "_readout")
        return forward_func(graph, embedding, info)