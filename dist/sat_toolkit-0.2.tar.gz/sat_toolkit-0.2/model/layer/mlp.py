import torch
import torch.nn as nn

class MLP(nn.Module):
  def __init__(self, 
               dim_in = 256, 
               dim_hidden = 128, 
               dim_pred = 1, 
               num_layer = 3, 
               norm_layer = None, 
               act_layer = None, 
               dropout_ratio = 0, 
               sigmoid = False, 
               tanh = False):
    super(MLP, self).__init__()
    '''
    The basic structure is refered from 
    '''
    # The number of layers shoud be larger or equal to 2.
    assert(num_layer >= 2)
    if dropout_ratio > 0:
        self.dropout = nn.Dropout
    self.act_layer = act_layer
    self.norm_layer = norm_layer
    
    fc = []
    # 1st layer
    fc.append(nn.Linear(dim_in, dim_hidden))
    if norm_layer:
        fc.append(self.norm_layer(dim_hidden))
    if act_layer:
        fc.append(self.act_layer(inplace=True))
    if dropout_ratio > 0:
        fc.append(self.dropout(dropout_ratio))
    for _ in range(num_layer - 2):
        fc.append(nn.Linear(dim_hidden, dim_hidden))
        if norm_layer:
            fc.append(self.norm_layer(dim_hidden))
        if act_layer:
            fc.append(self.act_layer(inplace=True))
        if dropout_ratio > 0:
            fc.append(self.dropout(dropout_ratio))
    # last layer
    fc.append(nn.Linear(dim_hidden, dim_pred))
    # sigmoid
    if sigmoid:
        fc.append(nn.Sigmoid())
    if tanh:
        fc.append(nn.Tanh())
    self.fc = nn.Sequential(*fc)

  def forward(self, x):
    out = self.fc(x)
    return out