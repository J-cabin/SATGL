from configurator import Config

if __name__ == "__main__":
    my_config = Config()
    print(my_config.config_dict)